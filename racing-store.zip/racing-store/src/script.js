javascript
function adicionarAoCarrinho(produto) {
    alert(produto + " foi adicionado ao carrinho!");
}